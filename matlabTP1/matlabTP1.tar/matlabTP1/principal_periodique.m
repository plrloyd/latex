% =====================================================
%
%
% une routine pour la mise en oeuvre des EF P1 Lagrange
% pour l'equation de Laplace suivante, avec conditions periodiques
% sur le maillage nom_maillage.msh
%
% | -div(A grad u ) u + u= f,   dans \Omega
% |         u periodique,   sur le bord
%
% =====================================================


% lecture du maillage et affichage
% ---------------------------------
nom_maillage = 'geomCarre_per.msh';
[Nbpt,Nbtri,Coorneu,Refneu,Numtri,Reftri,Nbaretes,Numaretes,Refaretes]=lecture_msh(nom_maillage);

% ----------------------
% calcul des matrices EF
% ----------------------

% declarations
% ------------
KK = sparse(Nbpt,Nbpt); % matrice de rigidite
MM = sparse(Nbpt,Nbpt); % matrice de rigidite
LL = zeros(Nbpt,1);     % vecteur second membre

% boucle sur les triangles
% ------------------------
for l=1:Nbtri
  % Coordonnees des sommets du triangles
  % A COMPLETER
  S1=Coorneu(Numtri(l,1),:);
  S2=Coorneu(Numtri(l,2),:);
  S3=Coorneu(Numtri(l,3),:);
  % calcul des matrices elementaires du triangle l 
  
   %Kel=matKvar_elem(S1, S2, S3);
   Kel=matK_elem(S1, S2, S3);
   Mel=matM_elem(S1, S2, S3);
    
  % On fait l'assemblage de la matrice globale et du second membre
  for i=1:3
      I = Numtri(l,i);
      for j=1:3
          J = Numtri(l,j);
          MM(I,J) = MM(I,J) + Mel(i,j);
          KK(I,J) = KK(I,J) + Kel(i,j);
      end
  end

end % for l

% Calcul du second membre L
% -------------------------
	% A COMPLETER
	% utiliser la routine f.m
FF = f(Coorneu(:,1),Coorneu(:,2));
LL = MM*FF;
AA=KK+MM;
% inversion
% ----------
[tilde_MM,tilde_LL]=elimine_periodique(MM,LL,Refneu);
[tilde_KK,tilde_LL]=elimine_periodique(KK,LL,Refneu);
test=Refneu==3 ;
test=test+Refneu==4;
test(2:4)=ones(3,1);
tilde_KK=tilde_KK-diag(test);
%UU = (MM+KK)\LL;
[tilde_AA,tilde_LL]=elimine_periodique(AA,LL,Refneu);
UU=tilde_AA\tilde_LL;
test=find(Refneu==1);
UU_final=UU;
%UU_final(2:4)=ones(3,1)*UU_final(1);
UU_final(find(Refneu==3))=UU(test(5:end));
UU_final(find(Refneu==4))=UU(find(Refneu==2));
% visualisation
% -------------
affiche(UU_final, Numtri, Coorneu, sprintf('Periodique - %s', nom_maillage));

validation = 'oui';
% validation
% ----------
if strcmp(validation,'oui')
UU_exact = sin(pi*Coorneu(:,1)+pi/2).*sin(pi*Coorneu(:,2)+pi/2);
%UU_exact(2:4)=zeros(3,1);
UU_exact=UU_exact.*(Refneu~=4).*(Refneu~=3);
% Calcul de l erreur L2
ErreurL2=(UU-UU_exact)'*(tilde_MM)*(UU-UU_exact)/((UU_exact)'*(tilde_MM)*(UU_exact))
% Calcul de l erreur H1
ErreurH1=(UU-UU_exact)'*tilde_KK*(UU-UU_exact)/((UU_exact)'*tilde_KK*(UU_exact))
% attention de bien changer le terme source (dans FF)
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                        fin de la routine
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

